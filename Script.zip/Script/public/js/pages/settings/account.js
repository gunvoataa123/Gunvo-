/**
 * Privacy settings component
 */
"use strict";

$(function () {

});

// eslint-disable-next-line no-unused-vars
var AccountSettings = {

};
