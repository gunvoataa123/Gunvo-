interface PingDelayOptions {
  minPingDelay?: number;
  maxPingDelay?: number;
  pingDelay?: number;
}

export default PingDelayOptions;
